﻿using System.Collections.Generic;
using System.Linq;
using Test_site.Data.Interfaces;
using Test_site.Data.Models;

namespace Test_site.Data.Mocks
{
    public class MockLaptops : IAllLaptops
    {
        private readonly ILaptopCategory _categoryLaptops = new MockCategory();

        public IEnumerable<Laptop> Laptops
        {
            get
            {
                return new List<Laptop>
                {
                 new Laptop{
                     Name = "Игровой ноутбук ASUS ROG Strix G15 G513IH-HN014",
                     shortDesc="15.6 1920 x 1080 IPS, 144 Гц, несенсорный, AMD Ryzen 7 4800H 2900 МГц, 16 ГБ DDR4, SSD 512 ГБ, видеокарта NVIDIA GeForce GTX 1650 4 ГБ GDDR6, без ОС, цвет крышки темно-серый",
                     longDesc="",
                     img="/img/asus.jpg",
                     price = 3550,
                     isFavorite=true,
                     avalible=true,
                     Category = _categoryLaptops.Allcategries.Last()
                 },
                 new Laptop
                 {
                     Name = "Игровой ноутбук Lenovo IdeaPad Gaming 3 15ACH6 82K200HERE ",
                     shortDesc="15.6 1920 x 1080 IPS, 60 Гц, несенсорный, AMD Ryzen 5 5600H 3300 МГц, 8 ГБ DDR4, SSD 512 ГБ, видеокарта NVIDIA GeForce GTX 1650 4 ГБ GDDR6, без ОС, цвет крышки черный",
                     longDesc="",
                     img="/img/lenovo.jpg",
                     price = 2980,
                     isFavorite=true,
                     avalible=true,
                     Category = _categoryLaptops.Allcategries.Last()
                 },
                 new Laptop
                 {
                     Name = "Ноутбук HONOR MagicBook X15 BBR-WAI9 53011UGC-001" ,
                     shortDesc="15.6 1920 x 1080 IPS, 60 Гц, несенсорный, Intel Core i3 10110U 2100 МГц, 8 ГБ DDR4, SSD 256 ГБ, видеокарта встроенная, Windows 10, цвет крышки серый",
                     longDesc="",
                     img="/img/honor.jpg",
                     price = 1699,
                     isFavorite=true,
                     avalible=true,
                     Category = _categoryLaptops.Allcategries.First()
                 },
                 new Laptop
                 {
                     Name = "Ноутбук Apple Macbook Pro 14 M1 Pro 2021 MKGR3" ,
                     shortDesc="14.2 3024 x 1964 IPS, 120 Гц, несенсорный, Apple M1 Pro (8 ядер), 16 ГБ, SSD 512 ГБ, видеокарта встроенная, Mac OS, цвет крышки серебристый",
                     longDesc="",
                     img="/img/Macbook.jpg",
                     price = 6479,
                     isFavorite=true,
                     avalible=true,
                     Category = _categoryLaptops.Allcategries.First()
                 },
                 new Laptop
                 {
                     Name = "Ноутбук ASUS VivoBook Pro 15 OLED K3500PC-L1085 " ,
                     shortDesc="15.6 1920 x 1080 OLED, 60 Гц, несенсорный, Intel Core i5 11300H 3100 МГц, 16 ГБ DDR4, SSD 512 ГБ, видеокарта NVIDIA GeForce RTX 3050 4 ГБ, без ОС, цвет крышки черный",
                     longDesc="",
                     img="/img/asus vivobook.jpg",
                     price = 3400,
                     isFavorite=true,
                     avalible=true,
                     Category = _categoryLaptops.Allcategries.First()
                 },
                 new Laptop
                 {
                     Name = "Ноутбук HP 255 G8 34P23ES " ,
                     shortDesc="15.6 1920 x 1080 IPS, 60 Гц, несенсорный, AMD Athlon Silver 3050U 2300 МГц, 8 ГБ DDR4, SSD 256 ГБ, видеокарта встроенная, без ОС, цвет крышки серебристый",
                     longDesc="",
                     img="/img/hp.jpg",
                     price = 1557,
                     isFavorite=true,
                     avalible=true,
                     Category = _categoryLaptops.Allcategries.First()
                 },

                };
            }
        }
        
        public IEnumerable<Laptop> getFavLaptops { get; set; }

        public Laptop getObjectLaptop(int laptopId)
        {
            throw new System.NotImplementedException();
        }
    }
}
