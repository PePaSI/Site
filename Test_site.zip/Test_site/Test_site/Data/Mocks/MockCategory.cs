﻿using System.Collections.Generic;
using Test_site.Data.Interfaces;
using Test_site.Data.Models;

namespace Test_site.Data.Mocks
{
    public class MockCategory : ILaptopCategory
    {
        public IEnumerable<Category> Allcategries
        {
            get
            {
                return new List<Category>
                {
                    new Category { categoryName = "Ноутбуки", desk = "Новинки" },
                    new Category { categoryName = "Игровые ноутбуки", desk = "Новинки" }
                };

            }
        }
    }
}
