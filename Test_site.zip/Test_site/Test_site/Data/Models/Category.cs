﻿using System.Collections.Generic;

namespace Test_site.Data.Models
{
    public class Category
    {
        public int Id { get; set; }
        public string categoryName { get; set; }
        public string desk { get; set; }
        public List<Laptop> Laptops { get; set; }

    }
}
