﻿namespace Test_site.Data.Models
{
    public class Laptop
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string shortDesc { get; set; }
        public string longDesc { get; set; }
        public string img { get; set; }
        public ushort price { get; set; }

        public bool isFavorite { get; set; }
        public bool avalible { get; set; }
        public int categoryID { get; set; }
        public virtual Category Category { get; set; }


    }
}
 