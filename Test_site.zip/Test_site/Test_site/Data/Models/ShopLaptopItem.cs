﻿namespace Test_site.Data.Models
{
    public class ShopLaptopItem
    {
        public int ItemId { get; set; }
        public Laptop laptop { get; set; }
        int price { get; set; }

        public string ShopLaptopID { get; set; }
    }
}
