﻿using System.Collections.Generic;
using Test_site.Data.Models;

namespace Test_site.Data.Interfaces
{
    public interface ILaptopCategory
    {
        IEnumerable<Category> Allcategries { get; }
    }
}
