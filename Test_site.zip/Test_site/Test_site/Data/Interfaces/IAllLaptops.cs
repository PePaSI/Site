﻿using System.Collections.Generic;
using Test_site.Data.Models;

namespace Test_site.Data.Interfaces
{
    public interface IAllLaptops
    {
        IEnumerable<Laptop> Laptops { get; }
        IEnumerable<Laptop> getFavLaptops { get;  set; }
        Laptop getObjectLaptop(int laptopId);
    }
}
