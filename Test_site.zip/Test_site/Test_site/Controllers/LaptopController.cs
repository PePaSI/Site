﻿using Microsoft.AspNetCore.Mvc;
using Test_site.Data.Interfaces;
using Test_site.ViewModels;

namespace Test_site.Controlles
{
    public class LaptopController : Controller
    {
        private readonly IAllLaptops _allLaptops;
        private readonly ILaptopCategory _allCategories;



        public LaptopController(IAllLaptops iAllLaptops, ILaptopCategory iLaptopCat)
        {
            _allLaptops= iAllLaptops;
            _allCategories= iLaptopCat;
        }

        public ViewResult List()
        {
            ViewBag.Title = "Страница с ноутбуками";
            LaptopListViewModel obj= new LaptopListViewModel();
            obj.allLaptops = _allLaptops.Laptops;
            obj.lapCategory = "Ноутбуки";
            
            return View(obj);
        }
       
    }
}
