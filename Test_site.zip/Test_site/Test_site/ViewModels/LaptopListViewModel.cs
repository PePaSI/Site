﻿using System.Collections.Generic;
using Test_site.Data.Models;

namespace Test_site.ViewModels
{
    public class LaptopListViewModel
    {
        public IEnumerable<Laptop> allLaptops { get; set; }
        public string lapCategory { get; set; }
    }
}
